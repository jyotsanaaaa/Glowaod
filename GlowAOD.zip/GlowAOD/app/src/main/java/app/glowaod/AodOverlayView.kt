package app.glowaod

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Draws wallpaper, clock, date, battery and notification icons. Used for the real overlay and the in-app preview. */
class AodOverlayView(ctx: Context) : View(ctx) {

    var settings: AodSettings = AodSettings()
        set(v) { field = v; invalidate() }
    var wallpaper: Bitmap? = null
        set(v) { field = v; invalidate() }
    var icons: List<Drawable> = emptyList()
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        setShadowLayer(6f * d, 0f, 2f * d, Color.argb(160, 0, 0, 0))
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        setShadowLayer(6f * d, 0f, 2f * d, Color.argb(160, 0, 0, 0))
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return
        c.drawColor(Color.BLACK)

        if (settings.showWallpaper) drawWallpaper(c, w, h)
        if (settings.dimPercent > 0) c.drawColor(Color.argb((settings.dimPercent * 2.55f).toInt(), 0, 0, 0))

        // Small position shift every minute to protect OLED pixels from burn-in.
        val now = Calendar.getInstance()
        val shift = ((now.get(Calendar.MINUTE) % 5) - 2) * 3f * d
        c.save()
        c.translate(shift, -shift)

        val cy = h * 0.40f
        when (settings.clockStyle) {
            2 -> drawAnalog(c, w / 2, cy, min(w, h) * 0.30f, now)
            1 -> {
                text.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
                text.textSize = w * 0.17f
                c.drawText(timeString(), w / 2, cy + text.textSize / 3, text)
            }
            else -> {
                text.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                text.textSize = w * 0.26f
                c.drawText(timeString(), w / 2, cy + text.textSize / 3, text)
            }
        }

        var y = h * 0.62f
        text.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        if (settings.showDate) {
            text.textSize = w * 0.06f
            c.drawText(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()), w / 2, y, text)
            y += w * 0.09f
        }
        if (settings.customText.isNotBlank()) {
            text.textSize = w * 0.055f
            c.drawText(settings.customText, w / 2, y, text)
        }
        if (settings.showBattery) drawBattery(c, w, h * 0.78f)
        if (settings.showNotifIcons && icons.isNotEmpty()) drawIcons(c, w, h * 0.88f)
        c.restore()
    }

    private fun timeString(): String =
        SimpleDateFormat(if (settings.use24h) "HH:mm" else "h:mm", Locale.getDefault()).format(Date())

    private fun drawWallpaper(c: Canvas, w: Float, h: Float) {
        val bmp = wallpaper
        if (bmp != null) {
            // center-crop
            val scale = maxOf(w / bmp.width, h / bmp.height)
            val dw = bmp.width * scale
            val dh = bmp.height * scale
            val dst = RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2)
            c.drawBitmap(bmp, null, dst, bgPaint)
        } else {
            // Built-in colourful gradient, generated in code (no asset files).
            bgPaint.shader = LinearGradient(
                0f, 0f, w, h,
                intArrayOf(Color.rgb(88, 44, 220), Color.rgb(224, 64, 140), Color.rgb(255, 150, 60)),
                null, Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w, h, bgPaint)
            bgPaint.shader = null
        }
    }

    private fun drawAnalog(c: Canvas, cx: Float, cy: Float, r: Float, now: Calendar) {
        stroke.strokeWidth = 3f * d
        c.drawCircle(cx, cy, r, stroke)
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0 - 90)
            val inner = r * 0.88f
            c.drawLine(
                cx + (cos(a) * inner).toFloat(), cy + (sin(a) * inner).toFloat(),
                cx + (cos(a) * r * 0.96f).toFloat(), cy + (sin(a) * r * 0.96f).toFloat(), stroke
            )
        }
        val m = now.get(Calendar.MINUTE)
        val hr = now.get(Calendar.HOUR) + m / 60f
        hand(c, cx, cy, hr / 12f * 360f, r * 0.50f, 5f * d)
        hand(c, cx, cy, m / 60f * 360f, r * 0.75f, 3f * d)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, sw: Float) {
        val a = Math.toRadians(deg - 90.0)
        stroke.strokeWidth = sw
        c.drawLine(cx, cy, cx + (cos(a) * len).toFloat(), cy + (sin(a) * len).toFloat(), stroke)
    }

    private fun drawBattery(c: Canvas, w: Float, y: Float) {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        if (level < 0) return
        val pct = (level * 100f / scale).toInt()
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val barW = w * 0.5f
        val barH = 6f * d
        val left = (w - barW) / 2
        fill.color = Color.argb(70, 255, 255, 255)
        c.drawRoundRect(RectF(left, y, left + barW, y + barH), barH, barH, fill)
        fill.color = if (pct <= 15 && !charging) Color.rgb(255, 90, 90) else Color.WHITE
        c.drawRoundRect(RectF(left, y, left + barW * pct / 100f, y + barH), barH, barH, fill)

        text.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        text.textSize = w * 0.045f
        c.drawText((if (charging) "⚡ " else "") + "$pct%", w / 2, y + barH + w * 0.065f, text)
    }

    private fun drawIcons(c: Canvas, w: Float, y: Float) {
        val size = 22f * d
        val gap = 10f * d
        val n = icons.size
        var x = (w - (n * size + (n - 1) * gap)) / 2
        for (ic in icons) {
            ic.setBounds(x.toInt(), y.toInt(), (x + size).toInt(), (y + size).toInt())
            ic.setTint(Color.WHITE)
            ic.draw(c)
            x += size + gap
        }
    }
}
