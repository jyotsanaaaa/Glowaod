package app.glowaod

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Draws the overlay on the cover display while it is in a low-power (doze) state.
 * It requests no accessibility events and no window content, so it cannot see
 * anything on screen; it only adds its own view.
 *
 * NOTE: cover-display behaviour differs between One UI versions. Detection of
 * "AOD is showing" uses the cover display's power state and may need tuning
 * on your device.
 */
class AodAccessibilityService : AccessibilityService() {

    private lateinit var dm: DisplayManager
    private var wm: WindowManager? = null
    private var view: AodOverlayView? = null
    private var wallpaper: Bitmap? = null
    private var coverId = -1

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) { coverId = findCover(); evaluate() }
        override fun onDisplayRemoved(displayId: Int) { coverId = findCover(); evaluate() }
        override fun onDisplayChanged(displayId: Int) { if (displayId == coverId) evaluate() }
    }

    private val tick = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (view != null) evaluate() // refresh time, or hide when schedule ends
        }
    }

    override fun onServiceConnected() {
        dm = getSystemService(DisplayManager::class.java)
        coverId = findCover()
        dm.registerDisplayListener(displayListener, Handler(Looper.getMainLooper()))
        registerReceiver(tick, IntentFilter(Intent.ACTION_TIME_TICK), Context.RECEIVER_NOT_EXPORTED)
        evaluate()
    }

    /** The cover display is the smallest non-default display. */
    private fun findCover(): Int =
        dm.displays
            .filter { it.displayId != Display.DEFAULT_DISPLAY }
            .minByOrNull { it.mode.physicalWidth.toLong() * it.mode.physicalHeight }
            ?.displayId ?: -1

    private fun evaluate() {
        val display = if (coverId >= 0) dm.getDisplay(coverId) else null
        if (display == null) { hide(); return }
        val s = display.state
        val inAod = s == Display.STATE_DOZE || s == Display.STATE_DOZE_SUSPEND ||
            s == Display.STATE_ON_SUSPEND
        if (inAod && Repo.get(this).activeNow()) show(display) else hide()
    }

    private fun show(display: Display) {
        val settings = Repo.get(this)
        if (wallpaper == null && settings.showWallpaper) wallpaper = Repo.loadWallpaper(this)
        val existing = view
        if (existing != null) {
            existing.settings = settings
            existing.wallpaper = wallpaper
            existing.icons = if (settings.showNotifIcons) NotifState.snapshot() else emptyList()
            return
        }
        val ctx = createDisplayContext(display)
        val manager = ctx.getSystemService(WindowManager::class.java)
        val v = AodOverlayView(ctx).apply {
            this.settings = settings
            this.wallpaper = this@AodAccessibilityService.wallpaper
            icons = if (settings.showNotifIcons) NotifState.snapshot() else emptyList()
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        )
        try {
            manager.addView(v, lp)
            wm = manager
            view = v
        } catch (_: Exception) {
            // Overlay not permitted on this display; fail quietly.
        }
    }

    private fun hide() {
        view?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        view = null
        wm = null
        wallpaper = null // drop decrypted wallpaper from memory while not showing
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* intentionally ignored */ }
    override fun onInterrupt() {}

    override fun onDestroy() {
        hide()
        try { dm.unregisterDisplayListener(displayListener) } catch (_: Exception) {}
        try { unregisterReceiver(tick) } catch (_: Exception) {}
        super.onDestroy()
    }
}
