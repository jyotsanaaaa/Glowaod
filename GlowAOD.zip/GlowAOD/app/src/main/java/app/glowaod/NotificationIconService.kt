package app.glowaod

import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** In-memory list of notification small-icons. Never stored, never includes text. */
object NotifState {
    private val map = LinkedHashMap<String, Drawable>()

    @Synchronized fun put(key: String, d: Drawable) { map[key] = d }
    @Synchronized fun remove(key: String) { map.remove(key) }
    @Synchronized fun clear() { map.clear() }
    @Synchronized fun snapshot(): List<Drawable> = map.values.take(6).toList()
}

/**
 * Only the notification's small icon is touched. Titles, text, senders and
 * extras are never read.
 */
class NotificationIconService : NotificationListenerService() {

    override fun onListenerConnected() {
        NotifState.clear()
        try { activeNotifications?.forEach { add(it) } } catch (_: Exception) {}
    }

    override fun onListenerDisconnected() = NotifState.clear()

    override fun onNotificationPosted(sbn: StatusBarNotification) = add(sbn)

    override fun onNotificationRemoved(sbn: StatusBarNotification) = NotifState.remove(sbn.key)

    private fun add(sbn: StatusBarNotification) {
        if (!Repo.get(this).showNotifIcons) return
        if (sbn.isOngoing) return
        val icon = try {
            sbn.notification.smallIcon?.loadDrawable(this)?.mutate()
        } catch (_: Exception) {
            null
        } ?: return
        NotifState.put(sbn.key, icon)
    }
}
