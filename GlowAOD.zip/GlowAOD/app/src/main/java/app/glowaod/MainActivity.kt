package app.glowaod

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import kotlin.math.max

class MainActivity : ComponentActivity() {

    private lateinit var s: AodSettings
    private lateinit var preview: AodOverlayView
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private val dp by lazy { resources.displayMetrics.density }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val bmp = decodeScaled(uri)
            Repo.saveWallpaper(this, bmp)
            preview.wallpaper = bmp
            toast("Wallpaper saved (encrypted)")
        } catch (e: Exception) {
            toast("Could not use that image")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Repo.get(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (16 * dp).toInt()
            setPadding(p, p, p, p)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(title("GlowAOD"))
        root.addView(body("Colourful cover-screen Always-On display. Everything is stored encrypted on this device only. The app has no internet permission."))

        // Preview (cover-screen-like proportions)
        preview = AodOverlayView(this).apply {
            settings = s
            wallpaper = Repo.loadWallpaper(this@MainActivity)
        }
        root.addView(preview, LinearLayout.LayoutParams((240 * dp).toInt(), (250 * dp).toInt()).apply {
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            topMargin = (12 * dp).toInt()
            bottomMargin = (12 * dp).toInt()
        })

        root.addView(section("Setup"))
        root.addView(button("1. Enable the GlowAOD accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(section("Wallpaper"))
        root.addView(button("Choose wallpaper from gallery") {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        })
        root.addView(button("Use built-in gradient") {
            Repo.deleteWallpaper(this); preview.wallpaper = null
        })
        addSwitch(root, "Show wallpaper", s.showWallpaper) { mutate { c -> c.copy(showWallpaper = it) } }
        root.addView(label("Dim wallpaper (saves battery)"))
        root.addView(SeekBar(this).apply {
            max = 90; progress = s.dimPercent
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) mutate { c -> c.copy(dimPercent = p) }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        root.addView(section("Clock"))
        root.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Digital", "Minimal", "Analog"))
            setSelection(s.clockStyle)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (pos != s.clockStyle) mutate { c -> c.copy(clockStyle = pos) }
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })
        addSwitch(root, "24-hour time", s.use24h) { mutate { c -> c.copy(use24h = it) } }
        addSwitch(root, "Show date", s.showDate) { mutate { c -> c.copy(showDate = it) } }
        addSwitch(root, "Show battery", s.showBattery) { mutate { c -> c.copy(showBattery = it) } }
        root.addView(label("Custom text (max 40 characters)"))
        root.addView(EditText(this).apply {
            setText(s.customText)
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { mutate { c -> c.copy(customText = e.toString().take(40)) } }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        })

        root.addView(section("Notification icons (optional)"))
        root.addView(body("Shows only the small icons of your notifications. Message text, titles and senders are never read."))
        addSwitch(root, "Show notification icons", s.showNotifIcons) { mutate { c -> c.copy(showNotifIcons = it) } }
        root.addView(button("Grant notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        root.addView(section("Schedule"))
        addSwitch(root, "Only show during set hours", s.scheduleEnabled) { mutate { c -> c.copy(scheduleEnabled = it) } }
        startBtn = button("") { pickTime(true) }
        endBtn = button("") { pickTime(false) }
        root.addView(startBtn); root.addView(endBtn)
        refreshTimeButtons()

        root.addView(section("Privacy"))
        root.addView(body("• Stored with AES-256-GCM; key kept in the Android Keystore.\n• No internet, storage, or location permissions.\n• Backups and device transfer are disabled.\n• The accessibility service requests no screen content."))
        root.addView(button("Delete all my data and encryption key") {
            AlertDialog.Builder(this)
                .setMessage("Delete the wallpaper, settings and encryption key from this device?")
                .setPositiveButton("Delete") { _, _ ->
                    Repo.wipeAll(this)
                    s = Repo.get(this)
                    preview.settings = s; preview.wallpaper = null
                    toast("All data deleted")
                    recreate()
                }
                .setNegativeButton("Cancel", null).show()
        })
    }

    private fun mutate(f: (AodSettings) -> AodSettings) {
        s = f(s)
        try { Repo.save(this, s) } catch (_: Exception) { toast("Could not save settings") }
        preview.settings = s
    }

    private fun pickTime(start: Boolean) {
        val cur = if (start) s.startMin else s.endMin
        TimePickerDialog(this, { _, h, m ->
            mutate { c -> if (start) c.copy(startMin = h * 60 + m) else c.copy(endMin = h * 60 + m) }
            refreshTimeButtons()
        }, cur / 60, cur % 60, true).show()
    }

    private fun refreshTimeButtons() {
        fun f(m: Int) = "%02d:%02d".format(m / 60, m % 60)
        startBtn.text = "Start: ${f(s.startMin)}"
        endBtn.text = "End: ${f(s.endMin)}"
    }

    private fun decodeScaled(uri: Uri): Bitmap {
        val src = ImageDecoder.createSource(contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > 1080) {
                val f = 1080f / m
                dec.setTargetSize((info.size.width * f).toInt(), (info.size.height * f).toInt())
            }
        }
    }

    // ---- tiny UI helpers ----
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun title(t: String) = TextView(this).apply { text = t; textSize = 28f }
    private fun section(t: String) = TextView(this).apply {
        text = t; textSize = 18f; setTextColor(0xFFFF9A3C.toInt())
        setPadding(0, (20 * dp).toInt(), 0, (6 * dp).toInt())
    }
    private fun body(t: String) = TextView(this).apply { text = t; textSize = 14f; setTextColor(0xFFCCCCCC.toInt()) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, (8 * dp).toInt(), 0, 0) }
    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }
    private fun addSwitch(root: LinearLayout, t: String, init: Boolean, onChange: (Boolean) -> Unit) {
        root.addView(Switch(this).apply {
            text = t; isChecked = init
            setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
            setOnCheckedChangeListener { _, v -> onChange(v) }
        })
    }
}
