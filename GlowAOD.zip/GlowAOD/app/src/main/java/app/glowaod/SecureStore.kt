package app.glowaod

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.nio.ByteBuffer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts everything the app stores (settings + wallpaper) with AES-256-GCM.
 * The key lives in the Android Keystore (hardware-backed where available) and
 * never leaves it, so the files are unreadable outside this app on this device.
 * File layout: [1 byte IV length][IV][ciphertext + 16-byte GCM tag]
 */
object SecureStore {
    private const val ALIAS = "glowaod_master_key"
    private const val TRANSFORM = "AES/GCM/NoPadding"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: ByteArray): ByteArray {
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.ENCRYPT_MODE, key()) // Keystore generates a fresh random IV
        val iv = c.iv
        val ct = c.doFinal(plain)
        return ByteBuffer.allocate(1 + iv.size + ct.size)
            .put(iv.size.toByte()).put(iv).put(ct).array()
    }

    fun decrypt(blob: ByteArray): ByteArray {
        val buf = ByteBuffer.wrap(blob)
        val iv = ByteArray(buf.get().toInt())
        buf.get(iv)
        val ct = ByteArray(buf.remaining())
        buf.get(ct)
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return c.doFinal(ct)
    }

    /** Atomic write so a crash never leaves a half-written file. */
    fun write(ctx: Context, name: String, plain: ByteArray) {
        val tmp = File(ctx.filesDir, "$name.tmp")
        tmp.writeBytes(encrypt(plain))
        if (!tmp.renameTo(File(ctx.filesDir, name))) {
            tmp.delete()
            throw java.io.IOException("Could not save $name")
        }
    }

    /** Returns null if missing or unreadable (e.g. key was wiped). */
    fun read(ctx: Context, name: String): ByteArray? = try {
        val f = File(ctx.filesDir, name)
        if (f.exists()) decrypt(f.readBytes()) else null
    } catch (e: Exception) {
        null
    }

    /** Deletes all stored files and the encryption key. */
    fun wipe(ctx: Context) {
        ctx.filesDir.listFiles()?.forEach { it.delete() }
        try {
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS)
        } catch (_: Exception) {
        }
    }
}
