package app.glowaod

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.io.ByteArrayOutputStream

data class AodSettings(
    val showWallpaper: Boolean = true,
    val clockStyle: Int = 0, // 0 digital, 1 minimal, 2 analog
    val use24h: Boolean = false,
    val showDate: Boolean = true,
    val showBattery: Boolean = true,
    val showNotifIcons: Boolean = false,
    val customText: String = "",
    val dimPercent: Int = 40,
    val scheduleEnabled: Boolean = false,
    val startMin: Int = 22 * 60,
    val endMin: Int = 7 * 60,
) {
    fun toJson(): String = JSONObject().apply {
        put("showWallpaper", showWallpaper)
        put("clockStyle", clockStyle)
        put("use24h", use24h)
        put("showDate", showDate)
        put("showBattery", showBattery)
        put("showNotifIcons", showNotifIcons)
        put("customText", customText)
        put("dimPercent", dimPercent)
        put("scheduleEnabled", scheduleEnabled)
        put("startMin", startMin)
        put("endMin", endMin)
    }.toString()

    /** True if the overlay should be shown right now (schedule may wrap past midnight). */
    fun activeNow(): Boolean {
        if (!scheduleEnabled) return true
        val c = java.util.Calendar.getInstance()
        val now = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
        return if (startMin <= endMin) now in startMin until endMin
        else now >= startMin || now < endMin
    }

    companion object {
        fun fromJson(s: String): AodSettings = try {
            val d = AodSettings()
            val j = JSONObject(s)
            AodSettings(
                j.optBoolean("showWallpaper", d.showWallpaper),
                j.optInt("clockStyle", d.clockStyle).coerceIn(0, 2),
                j.optBoolean("use24h", d.use24h),
                j.optBoolean("showDate", d.showDate),
                j.optBoolean("showBattery", d.showBattery),
                j.optBoolean("showNotifIcons", d.showNotifIcons),
                j.optString("customText", d.customText).take(40),
                j.optInt("dimPercent", d.dimPercent).coerceIn(0, 90),
                j.optBoolean("scheduleEnabled", d.scheduleEnabled),
                j.optInt("startMin", d.startMin).coerceIn(0, 1439),
                j.optInt("endMin", d.endMin).coerceIn(0, 1439),
            )
        } catch (e: Exception) {
            AodSettings()
        }
    }
}

/** Encrypted persistence for settings and the wallpaper. */
object Repo {
    private const val SETTINGS_FILE = "settings.enc"
    private const val WALLPAPER_FILE = "wallpaper.enc"

    @Volatile
    private var cached: AodSettings? = null

    fun get(ctx: Context): AodSettings = cached ?: run {
        val loaded = SecureStore.read(ctx, SETTINGS_FILE)?.let { AodSettings.fromJson(String(it)) }
            ?: AodSettings()
        cached = loaded
        loaded
    }

    fun save(ctx: Context, s: AodSettings) {
        cached = s
        SecureStore.write(ctx, SETTINGS_FILE, s.toJson().toByteArray())
    }

    /** Re-encodes as JPEG, which also strips EXIF/location metadata from the picked photo. */
    fun saveWallpaper(ctx: Context, bmp: Bitmap) {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
        SecureStore.write(ctx, WALLPAPER_FILE, out.toByteArray())
    }

    fun loadWallpaper(ctx: Context): Bitmap? =
        SecureStore.read(ctx, WALLPAPER_FILE)?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }

    fun deleteWallpaper(ctx: Context) {
        java.io.File(ctx.filesDir, WALLPAPER_FILE).delete()
    }

    fun wipeAll(ctx: Context) {
        cached = null
        SecureStore.wipe(ctx)
    }
}
