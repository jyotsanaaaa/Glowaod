# GlowAOD

A cover-screen Always-On Display app for Galaxy Z Flip phones. It shows a colourful wallpaper, a clock (digital, minimal or analog), date, battery, optional notification icons and your own text, with auto-dim and a daily schedule.

This is an original app. It is not a copy of CoverAOD and uses its own name and icon.

## Privacy and security design
- **No permissions at all.** The manifest has no INTERNET permission, so the app cannot send data anywhere.
- **Encrypted storage.** Settings and wallpaper are encrypted with AES-256-GCM. The key is generated in the Android Keystore and never leaves it (see `SecureStore.kt`).
- **No backups.** Cloud backup and device-to-device transfer are disabled, so the encrypted data stays on this phone.
- **Wallpaper privacy.** Picked photos are re-encoded as JPEG, which removes EXIF/location metadata. The photo picker is used, so no storage permission is needed.
- **Minimal accessibility service.** It declares no event types and no window-content access. It only draws its own overlay.
- **Notification icons are optional and off by default.** Only each notification's small icon is used. Titles, text and senders are never read, and nothing is stored.
- **Delete everything** button wipes the files and the encryption key.

## Build
1. Install Android Studio and open this folder.
2. Let Gradle sync, then run on a Galaxy Z Flip 5/6/7 (Android 13+).
3. In the app, tap "Enable the GlowAOD accessibility service" and turn it on.

## Important caveats
- **Not compiled or tested.** I could not build or run this here. Expect to fix small compile errors on the first build.
- **Cover display detection is best-effort.** The service treats the smallest non-default display in a doze/suspend state as "AOD is on". Samsung's One UI behaviour varies, so this may need tuning on your device. Check `evaluate()` in `AodAccessibilityService.kt`.
- Samsung may block or limit overlays on the cover display on some firmware versions.
- The original is sold with ads and in-app purchases. This one has none.
